<?php
// Hengyi Li

$db_host = 'borax.truman.edu';
$db_user = 'hl3265';
$db_pass = '53533265';
$db_db = 'hl3265';
?>
