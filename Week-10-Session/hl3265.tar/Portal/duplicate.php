
  <!DOCTYPE html>
  <html lang="en">

  <head>
    <meta charset="utf-8" />
    <title> Database Management System </title>
    <meta name="author" content="Hengyi Li" />
    <link rel="icon" href="../Resources/favicon.png">
    <link rel="stylesheet" href="managewords_portal.css" />
  </head>

  <body>
    <p class="prompt"> The username should be unique! Please choose another name! </p>
    <button type="submit" class="submit" id="signup_page">
      Try again
    </button>
    <script src="signup_jump.js"></script>
  </body>
  </html>
